
 <footer class="footer">
     <small style="  display: inline-block">
         © 2022 made with

     </small>
     <br />

 </footer>