<?php

namespace App\Http\Services;

class BrandService
{
    public function findAll($request)
    {
        $request = (object)$request;


    }
}
